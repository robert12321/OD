Download KITTI 3D object detection data and organize the folders as follows:

        dataset/KITTI/object/

            training/
                calib/
                image_2/
                label_2/ 
                velodyne/

            testing/
                calib/
                image_2/
                velodyne/ 
