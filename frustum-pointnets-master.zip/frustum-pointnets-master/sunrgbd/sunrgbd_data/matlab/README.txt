Compared with original SUNRGBD toolkits

removed metadata and GT data -- large files.
added detection/extract_gt_boxes.m to extract GT boxes
Under SUNRGBDtoolkit added
extract_data.m
extract_data_dimension.m
order_basis.m
