#/bin/bash
g++ -o evaluate_object_3d_offline evaluate_object_3d_offline.cpp
