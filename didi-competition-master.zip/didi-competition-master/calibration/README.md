## Camera/Lidar Calibration

You can find the camera calibration files here. Download the torrent to get the bag which you can use to generate calibration between Camera and Lidar for eg.

[Torrent](http://academictorrents.com/details/ffb0db5195d5e53041da6a7e168ce930987bc2ea)

Sensor transforms are available here [here](https://github.com/udacity/didi-competition/tree/master/mkz-description).
