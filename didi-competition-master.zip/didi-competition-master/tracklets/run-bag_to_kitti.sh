#!/bin/bash
./run.sh -r "python /python/bag_to_kitti.py" "$@"
